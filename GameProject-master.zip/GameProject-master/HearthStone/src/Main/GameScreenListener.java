package Main;
import java.awt.event.ActionEvent;

import model.heroes.Hero;

public interface GameScreenListener {
	public void actionPerformed(ActionEvent arg);

	
	
}
