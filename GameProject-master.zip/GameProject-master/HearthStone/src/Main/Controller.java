package Main;
import javax.swing.*;

import assets.CardButton;
import assets.alertBox;
import engine.Game;
import exceptions.FullHandException;
import model.cards.Card;
import model.heroes.Hero;

import java.awt.*;
import java.awt.event.*;
public class Controller implements ActionListener, WelcomeScreenListener, GameScreenListener{
	
	private WelcomeScreen welcomesc;
	private GameScreen gamesc;
	private Game game;
	
	public Controller(){
		welcomesc  = new WelcomeScreen();
		gamesc = new GameScreen();
		welcomesc.setListener(this);
		gamesc.setListener(this);
		
	}
	
	
	public static void main(String[] args) {
		new Controller();
	}

	public void actionPerformed(ActionEvent e) {
		// TODO button Actions 

		switch (e.getActionCommand()){
			case "start":
				welcomesc.setVisible(false);
				gamesc.setVisible(true);
				;break;
				
			case "draw":
				Card drawnCard = null;

				try {
					drawnCard = game.getCurrentHero().drawCard();
				} catch (FullHandException | CloneNotSupportedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				gamesc.updateInfo(game.getCurrentHero(), game.getOpponent());
				;break;

			case "endturn":
				System.out.println("Ending turn");
				;break;
				
			case "CardButton":
				CardButton btn = ((CardButton)e.getSource());
				if(!btn.isHidden()) {
					
//					TODO cardButton action
					
				}
				
				;break;
				
				
		}
		
		
		
		
	}


	@Override
	public void initializeGame(Hero p1, Hero p2) {
		try {
			game = new Game(p1, p2);
		} catch (FullHandException | CloneNotSupportedException e) {
			(new alertBox()).error("Error inisilizeing the game engine");
			e.printStackTrace();
		}
		
		
		gamesc.updateInfo(game.getCurrentHero(), game.getOpponent());
		
	}

	
	
	
	
	
	
}

