# GameProject
This Repository will contain our work.

# How to import/upload from-to this Repository?
Please watch this 10min video explaining the process
https://www.youtube.com/watch?v=LPT7v69guVY&t=140s


# Errors while importing:


"cannot open git-upload-pack",
Solution:
https://stackoverflow.com/questions/18813847/cannot-open-git-upload-pack-error-in-eclipse-when-cloning-or-pushing-git-repos
